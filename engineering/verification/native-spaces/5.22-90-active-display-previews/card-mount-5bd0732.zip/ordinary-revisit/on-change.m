#import <AppKit/AppKit.h>
#import <IOKit/IOKitLib.h>
#import "ReadOnlySpaces.h"

static NSString *ordinaryHome(void) {
    NSDictionary *session = CFBridgingRelease(CGSessionCopyCurrentDictionary());
    if (![session[(__bridge NSString *)kCGSessionOnConsoleKey] isEqual:@YES] ||
        [session[@"CGSSessionScreenIsLocked"] boolValue]) return nil;
    NSArray *inventory = CFBridgingRelease(NPReadInventory());
    if (inventory.count != 1) return nil;
    NSDictionary *home = inventory.firstObject[@"Current Space"];
    NSString *uuid = home[@"uuid"];
    return [home[@"type"] isEqual:@0] && [uuid isKindOfClass:NSString.class] &&
        [[NSUUID alloc] initWithUUIDString:uuid] ? uuid : nil;
}

static double inputIdle(void) {
    io_service_t service = IOServiceGetMatchingService(kIOMainPortDefault, IOServiceMatching("IOHIDSystem"));
    if (!service) return -1;
    id idle = CFBridgingRelease(IORegistryEntryCreateCFProperty(service, CFSTR("HIDIdleTime"), kCFAllocatorDefault, 0));
    IOObjectRelease(service);
    return [idle isKindOfClass:NSNumber.class] ? [idle doubleValue] * 1e-9 : -1;
}

int main(void) {
    @autoreleasepool {
        if (NPReadOnlySpacesOpen() != 1) return 4;
        __block NSInteger changes = 0;
        __block NSString *home = nil;
        __block NSDate *next = nil;
        NSDate *deadline = [NSDate dateWithTimeIntervalSinceNow:240];
        NSNotificationCenter *center = NSWorkspace.sharedWorkspace.notificationCenter;
        id monitor = [center addObserverForName:NSWorkspaceActiveSpaceDidChangeNotification object:nil
                    queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *n) {
            (void)n;
            changes++;
            home = ordinaryHome();
            next = home ? NSDate.date : nil;
        }];
        BOOL admitted = NO;
        double idle = -1;
        while (deadline.timeIntervalSinceNow > 0 && !admitted) {
            if (home && next.timeIntervalSinceNow <= 0) {
                idle = inputIdle();
                if (idle < 0) break;
                if (idle < 12) next = [NSDate dateWithTimeIntervalSinceNow:12-idle+.05];
                else {
                    admitted = [home isEqual:ordinaryHome()];
                    if (!admitted) { home = nil; next = nil; }
                }
            }
            if (!admitted)
                [NSRunLoop.currentRunLoop runMode:NSDefaultRunLoopMode beforeDate:next ? [next earlierDate:deadline] : deadline];
        }
        [center removeObserver:monitor];
        NSDictionary *receipt = @{@"method":@"One native Space change followed by simultaneous ordinary home and HID idle",
            @"spaceChanges":@(changes), @"lastHIDIdleSecondsOnOrdinary":@(idle), @"admitted":@(admitted),
            @"spaceWrites":@0, @"inputEventsSent":@0, @"deadlineSeconds":@240};
        NSData *json = [NSJSONSerialization dataWithJSONObject:receipt options:NSJSONWritingSortedKeys error:NULL];
        [[NSFileHandle fileHandleWithStandardOutput] writeData:json];
        return admitted ? 0 : 3;
    }
}
