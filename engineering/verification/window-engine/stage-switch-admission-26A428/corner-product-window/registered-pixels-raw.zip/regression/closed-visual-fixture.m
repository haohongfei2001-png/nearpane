#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
#import <libproc.h>
int main(void) {
 @autoreleasepool {
  const pid_t pid = 58625;
  char exe[PROC_PIDPATHINFO_MAXSIZE];
  errno=0;
  int probed = proc_pidpath(pid,exe,sizeof(exe)), err=errno;
  NSArray *windows = CFBridgingRelease(CGWindowListCopyWindowInfo(kCGWindowListOptionAll,kCGNullWindowID));
  NSUInteger owned=0;
  for (NSDictionary *w in windows) if ([w[(__bridge NSString *)kCGWindowOwnerPID] intValue]==pid) owned++;
  BOOL confirmed=probed<=0 && err==ESRCH && windows && owned==0;
  NSDictionary *row=@{@"scope":@"closed unregistered fixture owner only",@"pid":@(pid),
     @"processPathLookup":@(probed),@"processErrno":@(err),@"queriedWindowServer":@(windows!=nil),
     @"windowsOfClosedOwner":@(owned),@"status":confirmed?@"PASS":@"UNKNOWN",
     @"recordedUTC":[NSISO8601DateFormatter new] ? [[NSISO8601DateFormatter new] stringFromDate:[NSDate date]] : @""};
  NSData *data=[NSJSONSerialization dataWithJSONObject:row options:NSJSONWritingSortedKeys error:NULL];
  [NSFileHandle.fileHandleWithStandardOutput writeData:data]; return confirmed?0:2;
 }
}
