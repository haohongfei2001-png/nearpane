#import <AppKit/AppKit.h>
#import <libproc.h>
#import <Security/Security.h>
int main(void) { @autoreleasepool {
    NSString *image = @"/Applications/Nearpane.app/Contents/MacOS/NearpaneHost";
    NSArray *instances = [NSRunningApplication runningApplicationsWithBundleIdentifier:@"com.holdsnow.nearpane.alpha"];
    NSRunningApplication *host = instances.count == 1 ? instances.firstObject : nil;
    char path[PROC_PIDPATHINFO_MAXSIZE]; pid_t pid = host.processIdentifier;
    if (!host || pid <= 1 || proc_pidpath(pid,path,sizeof(path)) <= 0 || ![@(path) isEqual:image]) return 2;
    CGDirectDisplayID d = CGMainDisplayID(); CGRect screen = CGDisplayBounds(d); NSRect visible = NSScreen.screens.firstObject.visibleFrame;
    if (!CGDisplayIsActive(d) || CGDisplayIsInMirrorSet(d) || NSScreen.screens.count != 1) return 2;
    CGRect area = CGRectMake(CGRectGetMaxX(screen)-86, CGRectGetMaxY(screen)-visible.origin.y-176, 86, visible.origin.y+176);
    CFUUIDRef u = CGDisplayCreateUUIDFromDisplayID(d); NSString *display = CFBridgingRelease(CFUUIDCreateString(NULL,u)); CFRelease(u);
    NSMutableArray *samples = [NSMutableArray array];
    for (int i=0;i<2;i++) {
        NSArray *rows = CFBridgingRelease(CGWindowListCopyWindowInfo(kCGWindowListOptionOnScreenOnly,0)); if (!rows.count) return 2;
        NSMutableArray *owned = [NSMutableArray array], *systemLayers = [NSMutableArray array]; NSUInteger floating = 0, other = 0, desktop = 0;
        for (NSDictionary *row in rows) {
            CGRect f; if (!CGRectMakeWithDictionaryRepresentation((__bridge CFDictionaryRef)row[(id)kCGWindowBounds],&f)) return 2;
            if (![row[(id)kCGWindowIsOnscreen] boolValue] || [row[(id)kCGWindowAlpha] doubleValue] <= 0 || !CGRectIntersectsRect(f,area)) continue;
            int layer = [row[(id)kCGWindowLayer] intValue];
            if (layer != 0 && [row[(id)kCGWindowOwnerPID] intValue] != pid && layer >= CGWindowLevelForKey(kCGDesktopIconWindowLevelKey)) {
                NSString *identifier = [NSRunningApplication runningApplicationWithProcessIdentifier:[row[(id)kCGWindowOwnerPID] intValue]].bundleIdentifier;
                SecCodeRef running = NULL; SecRequirementRef rule = NULL; CFDictionaryRef info = NULL;
                pid_t layerPID = [row[(id)kCGWindowOwnerPID] intValue];
                if (layerPID > 1 && !SecCodeCopyGuestWithAttributes(NULL, (__bridge CFDictionaryRef)@{(__bridge NSString *)kSecGuestAttributePid:@(layerPID)},0,&running) &&
                    !SecRequirementCreateWithString(CFSTR("anchor apple"),0,&rule) && !SecCodeCheckValidity(running,0,rule) &&
                    !SecCodeCopySigningInformation(running,kSecCSSigningInformation,&info)) {
                    NSString *appleID = ((__bridge NSDictionary *)info)[(__bridge NSString *)kSecCodeInfoIdentifier];
                    identifier = [appleID hasPrefix:@"com.apple."] ? appleID : @"AppleSystemImage";
                } else identifier = @"unclassified";
                if (info) CFRelease(info); if (rule) CFRelease(rule); if (running) CFRelease(running);
                [systemLayers addObject:@{@"ownerKind":identifier, @"layer":@(layer), @"coversWholeDisplay":@(CGRectEqualToRect(f,screen))}];
            }
            if ([row[(id)kCGWindowOwnerPID] intValue] == pid) {
                [owned addObject:@{@"number":row[(id)kCGWindowNumber],@"layer":@(layer),@"frame":@[@(f.origin.x),@(f.origin.y),@(f.size.width),@(f.size.height)]}];
                if (layer == NSFloatingWindowLevel) floating++;
            } else if (layer > 0) other++; else if (layer >= CGWindowLevelForKey(kCGDesktopIconWindowLevelKey) && layer < 0) desktop++;
        }
        [samples addObject:@{@"uptime":@(NSProcessInfo.processInfo.systemUptime), @"installedNearpaneWindows":owned, @"systemLayers":systemLayers,@"installedFloatingWindows":@(floating),@"otherPositiveLayerWindowCount":@(other),@"desktopIconLayerWindowCount":@(desktop)}];
        if (!i) [NSThread sleepForTimeInterval:0.1];
    }
    NSDictionary *result = @{@"scope":@"read-only installed Nearpane window metadata at the full Corner preparation footprint; unrelated window IDs and titles excluded", @"pid":@(pid), @"installedPath":image,@"display":display,@"footprint":@[@(area.origin.x),@(area.origin.y),@(area.size.width),@(area.size.height)],@"samples":samples,@"windowsCreated":@0,@"windowWrites":@0,@"inputPosted":@0,@"captureFrames":@0};
    NSData *data = [NSJSONSerialization dataWithJSONObject:result options:NSJSONWritingPrettyPrinted|NSJSONWritingSortedKeys error:NULL]; fwrite(data.bytes,1,data.length,stdout); puts("");
    return 0;
} }
