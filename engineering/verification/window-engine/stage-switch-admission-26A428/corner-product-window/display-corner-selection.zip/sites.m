#import <AppKit/AppKit.h>
#import <ApplicationServices/ApplicationServices.h>
#import "nearpane_window_engine.h"
#import "scope_binding.h"
#import "patch_sheet.h"
#include <mach/mach_time.h>

static NSDictionary *homeNow(void) {
    CGDirectDisplayID displays[2]; uint32_t count=0;
    if (CGGetActiveDisplayList(2,displays,&count) || count!=1 || CGDisplayIsInMirrorSet(displays[0])) return nil;
    NSUUID *display = nc_single_main_uuid(1);
    if (!display) return nil;
    int32_t connection=0,error=0;
    NSArray *rows=CFBridgingRelease(np_host_scope_copy_managed(&connection,&error));
    if (error || rows.count!=1) return nil;
    NSDictionary *row=rows.firstObject;
    NSString *token=row[@"Display Identifier"];
    if (![token isKindOfClass:NSString.class]) return nil;
    uint64_t idNow=np_host_scope_direct(connection,(__bridge CFStringRef)token,&error);
    NSDictionary *scope=nc_bound_scope(row,display.UUIDString,YES,idNow,nil);
    return !error && idNow && [scope[@"native"] isEqual:@(idNow)] && nc_uuid(scope[@"space"])
        ? @{@"display":display.UUIDString,@"space":scope[@"space"],@"native":@(idNow)} : nil;
}

static NSDictionary *readOneSnapshot(void) {
    NSMutableDictionary *out=[@{@"purpose":@"physical site geometry only", @"status":@"UNKNOWN",
        @"windowWrites":@0,@"inputPosted":@0,@"storedPixels":@0,@"newPermissionRequests":@0} mutableCopy];
    NSDictionary *before=homeNow();
    CGRect screen=CGDisplayBounds(CGMainDisplayID());
    if (!before || !CGRectEqualToRect(screen,CGRectMake(0,0,1470,956))) return out;
    out[@"before"]=before;
    NSRunningApplication *front=NSWorkspace.sharedWorkspace.frontmostApplication;
    uint32_t hidBefore[13],hidAfter[13]; np_corner_inputs(hidBefore);
    NCMember scope={.native=[before[@"native"] unsignedLongLongValue]};
    [nc_uuid(before[@"display"]) getUUIDBytes:scope.display];
    [nc_uuid(before[@"space"]) getUUIDBytes:scope.space];
    // Exact test inputs on this 1470 x 956 display. The product derives its footprints
    // from its live reach, visible frame and physical neighbours, never these fixtures.
    NCFrame areas[]={{1384,780,86,176},{0,780,86,176},{1384,0,86,956},{0,0,86,956}};
    uint32_t reasons[4]={0};
    uint64_t begin=clock_gettime_nsec_np(CLOCK_UPTIME_RAW);
    uint32_t call=np_corner_patch_sites(&scope,areas,4,false,reasons);
    out[@"elapsedNS"]=@(clock_gettime_nsec_np(CLOCK_UPTIME_RAW)-begin);
    out[@"siteReaderStatus"]=@(call);
    if (!call) {
        NSMutableArray *sites=[NSMutableArray array];
        NSArray *names=@[@"bottomRight",@"bottomLeft",@"topRight",@"topLeft"];
        for (unsigned i=0;i<4;i++) [sites addObject:@{@"corner":names[i],@"reason":@(reasons[i]),
            @"area":@[@(areas[i].x),@(areas[i].y),@(areas[i].w),@(areas[i].h)]}];
        out[@"sites"]=sites;
    }
    NSDictionary *after=homeNow();
    if (after) out[@"after"]=after;
    np_corner_inputs(hidAfter);
    BOOL sameFront=front && [front isEqual:NSWorkspace.sharedWorkspace.frontmostApplication];
    BOOL sameHID=memcmp(hidBefore,hidAfter,sizeof(hidAfter))==0;
    out[@"foregroundStable"]=@(sameFront); out[@"inputCountersStable"]=@(sameHID);
    if (!call && [before isEqual:after] && sameFront && sameHID) out[@"status"]=@"OBSERVED";
    return out;
}
int main(void) { @autoreleasepool {
    [NSApplication sharedApplication];
    [NSApp setActivationPolicy:NSApplicationActivationPolicyProhibited];
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED,0), ^{
        @autoreleasepool {
            NSDictionary *result=readOneSnapshot();
            NSData *json=[NSJSONSerialization dataWithJSONObject:result options:NSJSONWritingPrettyPrinted|NSJSONWritingSortedKeys error:NULL];
            if (!json || fwrite(json.bytes,1,json.length,stdout)!=json.length) exit(3);
            puts(""); exit([result[@"status"] isEqual:@"OBSERVED"] ? 0 : 2);
        }
    });
    [NSRunLoop.mainRunLoop run]; return 3;
}}
