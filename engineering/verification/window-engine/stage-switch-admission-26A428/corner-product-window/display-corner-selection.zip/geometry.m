#import <AppKit/AppKit.h>
#import <ApplicationServices/ApplicationServices.h>
#import <Security/Security.h>
#import <dlfcn.h>
#import <unistd.h>

typedef AXError (*WindowNumber)(AXUIElementRef, CGWindowID *);
static WindowNumber numberOf;

static BOOL appleFinder(pid_t pid) {
    SecCodeRef guest = NULL;
    SecRequirementRef required = NULL;
    NSDictionary *attributes = @{(__bridge NSString *)kSecGuestAttributePid:@(pid)};
    BOOL valid = SecCodeCopyGuestWithAttributes(NULL, (__bridge CFDictionaryRef)attributes, 0, &guest) == errSecSuccess
        && SecRequirementCreateWithString(CFSTR("anchor apple and identifier \"com.apple.finder\""), 0, &required) == errSecSuccess
        && SecCodeCheckValidity(guest, kSecCSStrictValidate, required) == errSecSuccess;
    if (required) CFRelease(required);
    if (guest) CFRelease(guest);
    return valid;
}

static BOOL belongsToDesktop(AXUIElementRef node, pid_t pid, CGWindowID desktop) {
    pid_t actual = 0;
    if (!numberOf || !desktop || AXUIElementGetPid(node, &actual) != kAXErrorSuccess || actual != pid) return NO;
    CGWindowID w = 0;
    if (numberOf(node, &w) == kAXErrorSuccess && w == desktop) return YES;
    CFTypeRef window = NULL;
    if (AXUIElementCopyAttributeValue(node, kAXWindowAttribute, &window) != kAXErrorSuccess || !window) return NO;
    BOOL belongs = CFGetTypeID(window) == AXUIElementGetTypeID() &&
        numberOf((AXUIElementRef)window, &w) == kAXErrorSuccess && w == desktop;
    CFRelease(window);
    return belongs;
}

static NSString *genericRole(AXUIElementRef node) {
    CFTypeRef raw = NULL;
    if (AXUIElementCopyAttributeValue(node, kAXRoleAttribute, &raw) != kAXErrorSuccess || !raw) return @"unknown";
    id role = CFBridgingRelease(raw);
    NSArray *allowed = @[@"AXGroup", @"AXWindow", @"AXList", @"AXScrollArea", @"AXImage", @"AXButton", @"AXLayoutArea", @"AXBrowser", @"AXCell"];
    return [allowed containsObject:role] ? role : @"other";
}

static NSDictionary *readSite(CGDirectDisplayID display, pid_t pid) {
    CGRect screen = CGDisplayBounds(display);
    CGRect site = CGRectMake(CGRectGetMaxX(screen)-86, CGRectGetMaxY(screen)-176, 86, 176);
    CGWindowID desktop = 0;
    unsigned int matches = 0;
    NSArray *rows = CFBridgingRelease(CGWindowListCopyWindowInfo(kCGWindowListOptionOnScreenOnly, 0));
    for (NSDictionary *row in rows) {
        if ([row[(__bridge NSString *)kCGWindowOwnerPID] intValue] != pid ||
            [row[(__bridge NSString *)kCGWindowLayer] intValue] != CGWindowLevelForKey(kCGDesktopIconWindowLevelKey)) continue;
        CGRect box = CGRectZero;
        if (!CGRectMakeWithDictionaryRepresentation((__bridge CFDictionaryRef)row[(__bridge NSString *)kCGWindowBounds], &box) ||
            !CGRectEqualToRect(screen, box)) continue;
        matches++;
        desktop = [row[(__bridge NSString *)kCGWindowNumber] unsignedIntValue];
    }
    NSMutableDictionary *out = [@{@"uptime":@(NSProcessInfo.processInfo.systemUptime), @"finderFullDisplayIconLayers":@(matches),
        @"site":@[@(site.origin.x),@(site.origin.y),@(site.size.width),@(site.size.height)]} mutableCopy];
    if (matches != 1 || !desktop || !numberOf || !AXIsProcessTrusted()) return out;
    AXUIElementRef app = AXUIElementCreateApplication(pid);
    AXUIElementSetMessagingTimeout(app,0.15);
    NSMutableArray *hit = [NSMutableArray array];
    CGPoint relative[] = {{1,1},{84,1},{43,88},{1,174},{84,174}};
    for (size_t i=0;i<sizeof(relative)/sizeof(*relative);i++) {
        AXUIElementRef element = NULL;
        AXError status = AXUIElementCopyElementAtPosition(app, site.origin.x + relative[i].x,
            site.origin.y + relative[i].y, &element);
        BOOL matched = status == kAXErrorSuccess && element && belongsToDesktop(element, pid, desktop);
        NSMutableDictionary *item = [@{@"error":@(status),@"boundToDesktop":@(matched)} mutableCopy];
        if (matched) item[@"role"] = genericRole(element);
        if (element) CFRelease(element);
        [hit addObject:item];
    }
    out[@"finderScopedHitTests"] = hit;
    CFIndex count = 0;
    AXError counted = AXUIElementGetAttributeValueCount(app, kAXWindowsAttribute, &count);
    out[@"windowsCountStatus"] = @(counted);
    if (counted == kAXErrorSuccess && count >= 0 && count <= 128) {
        BOOL listed = NO;
        CFArrayRef windows = NULL;
        if (count && AXUIElementCopyAttributeValues(app,kAXWindowsAttribute,0,count,&windows) == kAXErrorSuccess && windows) {
            for (CFIndex i=0;i<CFArrayGetCount(windows);i++) {
                AXUIElementRef w = CFArrayGetValueAtIndex(windows,i);
                CGWindowID idNumber = 0;
                if (CFGetTypeID(w) == AXUIElementGetTypeID() && numberOf(w,&idNumber) == kAXErrorSuccess && idNumber == desktop) listed = YES;
            }
            CFRelease(windows);
        }
        out[@"desktopListedAsAXWindow"] = @(listed);
    }
    CFRelease(app);
    return out;
}

int main(void) { @autoreleasepool {
    numberOf = (WindowNumber)dlsym(RTLD_DEFAULT,"_AXUIElementGetWindow");
    NSArray<NSRunningApplication *> *finders = [NSRunningApplication runningApplicationsWithBundleIdentifier:@"com.apple.finder"];
    NSRunningApplication *finder = finders.count == 1 ? finders.firstObject : nil;
    CGDirectDisplayID displays[2]; uint32_t count = 0;
    BOOL single = CGGetActiveDisplayList(2,displays,&count) == kCGErrorSuccess && count == 1 && !CGDisplayIsInMirrorSet(displays[0]);
    BOOL signedFinder = finder && appleFinder(finder.processIdentifier);
    NSMutableDictionary *out = [@{@"axTrusted":@(AXIsProcessTrusted()), @"singleDisplay":@(single),
        @"appleSignedFinder":@(signedFinder), @"newPermissionRequests":@0, @"images":@0, @"inputs":@0,
        @"windowWrites":@0, @"readsWindowTitles":@NO, @"readsDocumentValues":@NO} mutableCopy];
    if (single && signedFinder && !finder.terminated) {
        CFUUIDRef uuid = CGDisplayCreateUUIDFromDisplayID(displays[0]);
        if (uuid) {out[@"displayUUID"] = CFBridgingRelease(CFUUIDCreateString(NULL,uuid)); CFRelease(uuid);}
        out[@"finderPID"] = @(finder.processIdentifier);
        if (finder.launchDate) out[@"finderLaunchTime"] = @(finder.launchDate.timeIntervalSince1970);
        NSDictionary *first = readSite(displays[0],finder.processIdentifier);
        usleep(125000);
        if (!finder.terminated) out[@"samples"] = @[first,readSite(displays[0],finder.processIdentifier)];
    }
    NSData *data = [NSJSONSerialization dataWithJSONObject:out options:NSJSONWritingPrettyPrinted|NSJSONWritingSortedKeys error:NULL];
    if (!data || fwrite(data.bytes,1,data.length,stdout) != data.length) return 1;
    puts("");
    return 0;
}}
