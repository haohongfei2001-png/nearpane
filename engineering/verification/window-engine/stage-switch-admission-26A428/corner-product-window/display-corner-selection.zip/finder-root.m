#define main finderGeometryMain
#import "geometry.m"
#undef main

static BOOL coversDisplay(AXUIElementRef node, CGRect display) {
    CFTypeRef p=NULL,s=NULL;
    CGPoint origin=CGPointZero; CGSize size=CGSizeZero;
    BOOL ok=AXUIElementCopyAttributeValue(node,kAXPositionAttribute,&p)==kAXErrorSuccess &&
        AXUIElementCopyAttributeValue(node,kAXSizeAttribute,&s)==kAXErrorSuccess &&
        p && s && CFGetTypeID(p)==AXValueGetTypeID() && CFGetTypeID(s)==AXValueGetTypeID() &&
        AXValueGetValue(p,kAXValueCGPointType,&origin) && AXValueGetValue(s,kAXValueCGSizeType,&size) &&
        CGRectEqualToRect((CGRect){origin,size},display);
    if (p) CFRelease(p);
    if (s) CFRelease(s);
    return ok;
}

static NSDictionary *roots(AXUIElementRef app, pid_t pid, CGRect display) {
    CFIndex count=0;
    AXError e=AXUIElementGetAttributeValueCount(app,kAXChildrenAttribute,&count);
    NSMutableDictionary *r=[@{@"childrenStatus":@(e)} mutableCopy];
    if(e!=kAXErrorSuccess || count<1 || count>128) return r;
    CFArrayRef raw=NULL;
    e=AXUIElementCopyAttributeValues(app,kAXChildrenAttribute,0,count,&raw);
    r[@"childrenReadStatus"]=@(e);
    if(e!=kAXErrorSuccess || !raw) return r;
    NSArray *children=CFBridgingRelease(raw);
    NSMutableArray *containers=[NSMutableArray array];
    for(id object in children) {
        AXUIElementRef item=(__bridge AXUIElementRef)object;
        pid_t actual=0;
        if(CFGetTypeID(item)!=AXUIElementGetTypeID() || AXUIElementGetPid(item,&actual)!=kAXErrorSuccess || actual!=pid) continue;
        NSString *role=genericRole(item);
        if(![@[@"AXScrollArea",@"AXList",@"AXGroup",@"AXLayoutArea"] containsObject:role]) continue;
        // Only app-level containers with an exact physical-display frame qualify for comparison.
        if(coversDisplay(item,display)) [containers addObject:object];
    }
    NSMutableArray *candidates=[NSMutableArray array];
    for(id object in containers) [candidates addObject:genericRole((__bridge AXUIElementRef)object)];
    r[@"fullDisplayAppLevelContainerRoles"]=candidates;
    CGPoint p[]={{1385,781},{1468,781},{1427,868},{1385,954},{1468,954}};
    unsigned finder=0,matched=0;
    for(unsigned i=0;i<5;i++) {
        AXUIElementRef hit=NULL;
        if(AXUIElementCopyElementAtPosition(app,p[i].x,p[i].y,&hit)!=kAXErrorSuccess || !hit) continue;
        BOOL isMatch=NO;
        for(unsigned depth=0;depth<8;depth++) {
            pid_t actual=0;
            if(AXUIElementGetPid(hit,&actual)!=kAXErrorSuccess || actual!=pid) break;
            if(!depth) finder++;
            if([containers containsObject:(__bridge id)hit]) { isMatch=YES; break; }
            // Ordinary Finder windows are outside the scope of this observation.
            if([genericRole(hit) isEqual:@"AXWindow"]) break;
            CFTypeRef parent=NULL;
            if(AXUIElementCopyAttributeValue(hit,kAXParentAttribute,&parent)!=kAXErrorSuccess || !parent) break;
            if(CFGetTypeID(parent)!=AXUIElementGetTypeID() || CFEqual(parent,hit)) { CFRelease(parent); break; }
            CFRelease(hit); hit=(AXUIElementRef)parent;
        }
        if(isMatch) matched++;
        CFRelease(hit);
    }
    r[@"pointCount"]=@5; r[@"finderOwnedHits"]=@(finder); r[@"hitsBoundToFullDisplayContainer"]=@(matched);
    return r;
}
int main(void) { @autoreleasepool {
    NSArray *apps=[NSRunningApplication runningApplicationsWithBundleIdentifier:@"com.apple.finder"];
    NSRunningApplication *f=apps.count==1 ? apps.firstObject : nil;
    CGRect display=CGDisplayBounds(CGMainDisplayID());
    NSMutableDictionary *r=[@{@"status":@"BLOCKED",@"scope":@"public Finder app-level container geometry and hit ancestry",
        @"windowWrites":@0,@"inputs":@0,@"pixels":@0,@"documentContents":@0,@"namesRead":@0} mutableCopy];
    if(f && !f.terminated && appleFinder(f.processIdentifier) && AXIsProcessTrusted() &&
        CGRectEqualToRect(display,CGRectMake(0,0,1470,956))) {
        AXUIElementRef app=AXUIElementCreateApplication(f.processIdentifier);
        AXUIElementSetMessagingTimeout(app,0.12);
        NSDictionary *first=roots(app,f.processIdentifier,display);
        usleep(125000);
        NSDictionary *second=roots(app,f.processIdentifier,display);
        r[@"samples"]=@[first,second]; r[@"sameProcess"]=@(!f.terminated);
        r[@"status"]=(!f.terminated && [first isEqual:second] && second[@"pointCount"]) ? @"OBSERVED" : @"UNKNOWN";
        CFRelease(app);
    }
    NSData *data=[NSJSONSerialization dataWithJSONObject:r options:NSJSONWritingPrettyPrinted|NSJSONWritingSortedKeys error:NULL];
    if(!data || fwrite(data.bytes,1,data.length,stdout)!=data.length) return 3;
    puts("");return [r[@"status"] isEqual:@"OBSERVED"] ? 0 : 2;
}}
