#import <AppKit/AppKit.h>
#import <Security/Security.h>
#import "scope_binding.h"
#import "nearpane_window_engine.h"
#import "macos.h"

static NSDictionary *home(void) {
    int32_t connection = 0, error = 0;
    NSArray *rows = CFBridgingRelease(np_host_scope_copy_managed(&connection, &error));
    NSUUID *display = nc_single_main_uuid(rows.count);
    if (error || rows.count != 1 || !display) return nil;
    NSString *token = rows[0][@"Display Identifier"];
    if (![token isKindOfClass:NSString.class]) return nil;
    uint64_t n = np_host_scope_direct(connection, (__bridge CFStringRef)token, &error);
    NSDictionary *result = nc_bound_scope(rows[0], display.UUIDString, YES, n, nil);
    return !error && n && [result[@"native"] isEqual:@(n)] && nc_uuid(result[@"space"]) ?
        @{@"display": display.UUIDString, @"space": result[@"space"], @"native": @(n)} : nil;
}
static int recognized(NSString *bundle) {
    NSArray *apps = [NSRunningApplication runningApplicationsWithBundleIdentifier:bundle];
    if (apps.count != 1) return -1;
    NSRunningApplication *app = apps[0];
    SecCodeRef guest = NULL;
    SecRequirementRef requirement = NULL;
    NSString *rule = [NSString stringWithFormat:@"anchor apple and identifier \"%@\"", bundle];
    NSDictionary *attrs = @{(__bridge NSString *)kSecGuestAttributePid:@(app.processIdentifier)};
    BOOL valid = SecCodeCopyGuestWithAttributes(NULL, (__bridge CFDictionaryRef)attrs, 0, &guest) == errSecSuccess &&
        SecRequirementCreateWithString((__bridge CFStringRef)rule, 0, &requirement) == errSecSuccess &&
        SecCodeCheckValidity(guest, kSecCSStrictValidate, requirement) == errSecSuccess && !app.terminated;
    if (guest) CFRelease(guest);
    if (requirement) CFRelease(requirement);
    return valid ? app.processIdentifier : -1;
}
static NSArray *rowsNow(void) {
    return CFBridgingRelease(CGWindowListCopyWindowInfo(kCGWindowListOptionOnScreenOnly, kCGNullWindowID));
}
static NSArray *snapshot(void) {
    CGRect screen = CGDisplayBounds(CGMainDisplayID());
    if (!CGRectEqualToRect(screen, CGRectMake(0,0,1470,956))) return nil;
    int overlay = recognized(@"com.apple.screencaptureui"), finder = recognized(@"com.apple.finder");
    NSArray *rows = rowsNow();
    if (!rows.count || overlay <= 0 || finder <= 0) return nil;
    NSMutableDictionary *indices = [NSMutableDictionary dictionary], *roles = [NSMutableDictionary dictionary];
    NSNumber *fullOverlay = nil;
    for (NSUInteger i = 0; i < rows.count; i++) {
        NSDictionary *r = rows[i];
        NSNumber *n = r[(__bridge NSString *)kCGWindowNumber];
        CGRect frame = {};
        if (!n || indices[n] || !CGRectMakeWithDictionaryRepresentation(
                (__bridge CFDictionaryRef)r[(__bridge NSString *)kCGWindowBounds],&frame)) return nil;
        indices[n] = @(i);
        int pid = [r[(__bridge NSString *)kCGWindowOwnerPID] intValue];
        NSInteger layer = [r[(__bridge NSString *)kCGWindowLayer] integerValue];
        if (pid == overlay && layer == 24 && CGRectEqualToRect(frame, screen) &&
                [r[(__bridge NSString *)kCGWindowAlpha] doubleValue] > 0) {
            if (fullOverlay) return nil;
            fullOverlay = n;
            roles[n] = @"appleScreenshotSurface";
        } else if (pid == finder && layer == CGWindowLevelForKey(kCGDesktopIconWindowLevelKey))
            roles[n] = @"finderDesktop";
    }
    if (!fullOverlay) return nil;
    CGRect boxes[] = {{ {1384,780},{86,176}}, {{0,780},{86,176}}, {{1384,0},{86,956}}, {{0,0},{86,956}}};
    NSArray *names = @[@"bottomRight",@"bottomLeft",@"topRight",@"topLeft"];
    NSMutableArray *samples = [NSMutableArray array];
    for (unsigned i = 0; i < 4; i++) {
        CGRect box = boxes[i];
        double x0 = CGRectGetMinX(box)+1, x1 = CGRectGetMaxX(box)-1, y0 = CGRectGetMinY(box)+1, y1 = CGRectGetMaxY(box)-1;
        CGPoint points[] = {{x0,y0},{x1,y0},{CGRectGetMidX(box),CGRectGetMidY(box)},{x0,y1},{x1,y1}};
        NSMutableArray *hits = [NSMutableArray array];
        for (unsigned j=0;j<5;j++) {
            NSPoint p = NSMakePoint(points[j].x, CGRectGetMaxY(screen)-points[j].y);
            NSNumber *n = @([NSWindow windowNumberAtPoint:p belowWindowWithWindowNumber:0]);
            NSNumber *below = @([NSWindow windowNumberAtPoint:p belowWindowWithWindowNumber:fullOverlay.integerValue]);
            NSString *which = !indices[n] ? @"unresolved" : (roles[n] ?: @"other");
            NSString *where = !indices[n] ? @"unknown" : ([indices[n] compare:indices[fullOverlay]] == NSOrderedDescending ? @"below" :
                                  ([n isEqual:fullOverlay] ? @"overlay" : @"above"));
            [hits addObject:@{@"topHit":which,@"relativeToAppleScreenshotSurface":where,
                              @"sameAsSearchBelowSurface":@([n isEqual:below] && indices[n] != nil)}];
        }
        [samples addObject:@{@"site":names[i],@"hits":hits}];
    }
    // Recheck all exposed ordering facts before returning the counts. No names or pixels are read.
    NSArray *end = rowsNow();
    NSString *numberKey = (__bridge NSString *)kCGWindowNumber;
    if (![[end valueForKey:numberKey] isEqual:[rows valueForKey:numberKey]]) return nil;
    return samples;
}
int main(void) { @autoreleasepool {
    [NSApplication sharedApplication];
    [NSApp setActivationPolicy:NSApplicationActivationPolicyProhibited];
    NSDictionary *before = home();
    pid_t front = NSWorkspace.sharedWorkspace.frontmostApplication.processIdentifier;
    uint32_t start[13], end[13];
    np_corner_inputs(start);
    NSArray *first = before ? snapshot() : nil;
    [NSThread sleepForTimeInterval:.16];
    NSArray *second = before ? snapshot() : nil;
    NSDictionary *after = home();
    np_corner_inputs(end);
    BOOL stableInput = memcmp(start,end,sizeof(start)) == 0;
    BOOL stableFront = front>0 && front == NSWorkspace.sharedWorkspace.frontmostApplication.processIdentifier;
    BOOL stable = [first isEqual:second] && stableInput && stableFront && [before isEqual:after];
    NSDictionary *out = @{@"status":stable ? @"OBSERVED" : @"UNKNOWN", @"before":before ?: NSNull.null,
        @"after":after ?: NSNull.null, @"hidStable":@(stableInput),@"foregroundStable":@(stableFront),
        @"first":first ?: NSNull.null, @"second":second ?: NSNull.null, @"time":@([NSDate date].timeIntervalSince1970),
        @"api":@"NSWindow.windowNumber(at:belowWindowWithWindowNumber:)", @"sentEvents":@0,@"capturedImages":@0,
        @"windowWrites":@0,@"readTitlesOrDocuments":@NO,@"gestureDelivery":@"NOT_RUN",@"visualOcclusion":@"NOT_RUN"};
    NSData *json = [NSJSONSerialization dataWithJSONObject:out options:NSJSONWritingSortedKeys|NSJSONWritingPrettyPrinted error:NULL];
    if (!json || fwrite(json.bytes,1,json.length,stdout)!=json.length) return 3;
    puts("");
    return stable ? 0 : 2;
}}
