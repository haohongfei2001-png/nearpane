#import <AppKit/AppKit.h>
#import "ReadOnlySpaces.h"
int main(void) {
    @autoreleasepool {
        if (NPReadOnlySpacesOpen() != 1) return 4;
        NSNotificationCenter *center = NSWorkspace.sharedWorkspace.notificationCenter;
        __block NSUInteger notifications = 0;
        __block BOOL ordinary = NO;
        id token = [center addObserverForName:NSWorkspaceActiveSpaceDidChangeNotification object:nil
                                        queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification *note) {
            (void)note;
            notifications++;
            NSArray *scopes = CFBridgingRelease(NPReadInventory());
            if (scopes.count != 1) return;
            NSDictionary *s = scopes.firstObject[@"Current Space"];
            if ([s[@"type"] isEqual:@0] && [s[@"uuid"] isKindOfClass:NSString.class] &&
                [[NSUUID alloc] initWithUUIDString:s[@"uuid"]]) ordinary = YES;
        }];
        NSDate *until = [NSDate dateWithTimeIntervalSinceNow:240];
        do {
            [NSRunLoop.currentRunLoop runMode:NSDefaultRunLoopMode beforeDate:until];
        } while (!ordinary && until.timeIntervalSinceNow > 0);
        [center removeObserver:token];
        NSDictionary *row = @{@"method":@"NSWorkspace activeSpaceDidChange", @"notifications":@(notifications),
                              @"ordinaryOnNotification":@(ordinary), @"windowActions":@0, @"inputEvents":@0};
        NSData *data = [NSJSONSerialization dataWithJSONObject:row options:0 error:NULL];
        [[NSFileHandle fileHandleWithStandardOutput] writeData:data];
        return ordinary ? 0 : 3;
    }
}
