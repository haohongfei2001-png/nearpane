import Foundation
import NearpaneCore

func sample() -> [String: Any] {
    let before = StageManagerPreference.read()
    let native = readNativeYield()
    let after = StageManagerPreference.read()
    return ["hostBefore": before as Any, "nativeYields": native, "hostAfter": after as Any,
            "sameDecision": before != nil && before == after && native == (after == false)]
}
let first = sample()
Thread.sleep(forTimeInterval: 0.125)
let second = sample()
let stable = first["sameDecision"] as? Bool == true && second["sameDecision"] as? Bool == true &&
    first["nativeYields"] as? Bool == second["nativeYields"] as? Bool
let receipt: [String: Any] = ["scope":"read-only Host and native engine configuration on the target machine",
    "status":stable ? "PASS" : "UNKNOWN","samples":[first,second],"configurationWrites":0,"windowWrites":0,
    "actualTakeoverDuringRetirement":"NOT_RUN"]
FileHandle.standardOutput.write(try JSONSerialization.data(withJSONObject:receipt,options:[.prettyPrinted,.sortedKeys]))
print()
