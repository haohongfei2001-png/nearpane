#include <stdbool.h>
bool readNativeYield(void);
