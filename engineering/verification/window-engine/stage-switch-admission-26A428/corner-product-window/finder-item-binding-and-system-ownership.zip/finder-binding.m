#define main finderGeometryMain
#import "geometry.m"
#undef main

static BOOL coversDisplay(AXUIElementRef node, CGRect display) {
    CFTypeRef p=NULL,s=NULL;
    CGPoint origin=CGPointZero; CGSize size=CGSizeZero;
    BOOL ok=AXUIElementCopyAttributeValue(node,kAXPositionAttribute,&p)==kAXErrorSuccess &&
        AXUIElementCopyAttributeValue(node,kAXSizeAttribute,&s)==kAXErrorSuccess &&
        p && s && CFGetTypeID(p)==AXValueGetTypeID() && CFGetTypeID(s)==AXValueGetTypeID() &&
        AXValueGetValue(p,kAXValueCGPointType,&origin) && AXValueGetValue(s,kAXValueCGSizeType,&size) &&
        CGRectEqualToRect((CGRect){origin,size},display);
    if (p) CFRelease(p);
    if (s) CFRelease(s);
    return ok;
}

// Inspect only role/geometry of descendants of a uniquely matched, direct full-display Finder scroll area.
// Keep only aggregate counts; never fetch names, URLs, filenames, contents, selections or images.
static CGWindowID iconWindow(pid_t pid) {
    CGWindowID idNumber=0; unsigned matches=0;
    NSArray *rows=CFBridgingRelease(CGWindowListCopyWindowInfo(kCGWindowListOptionOnScreenOnly,0));
    for(NSDictionary *row in rows) {
        CGRect f=CGRectZero;
        if([row[(__bridge NSString *)kCGWindowOwnerPID] intValue]==pid && [row[(__bridge NSString *)kCGWindowLayer] intValue]==CGWindowLevelForKey(kCGDesktopIconWindowLevelKey) &&
            CGRectMakeWithDictionaryRepresentation((__bridge CFDictionaryRef)row[(__bridge NSString *)kCGWindowBounds],&f) && CGRectEqualToRect(f,CGDisplayBounds(CGMainDisplayID()))) {
            idNumber=[row[(__bridge NSString *)kCGWindowNumber] unsignedIntValue]; matches++;
        }
    }
    return matches==1 ? idNumber : 0;
}
static NSDictionary *inventory(AXUIElementRef root, pid_t pid) {
    NSMutableDictionary *stats=[@{@"completeGeometry":@YES} mutableCopy];
    NSMutableArray *level=[NSMutableArray arrayWithObject:(__bridge id)root];
    NSMutableSet *seen=[NSMutableSet setWithArray:level];
    NSMutableDictionary *roleCounts=[NSMutableDictionary dictionary];
    unsigned overlap[4]={0}, nativeBound=0, hitMatches=0, measuredItems=0;
    numberOf=(WindowNumber)dlsym(RTLD_DEFAULT,"_AXUIElementGetWindow");
    CGWindowID iconPlane=iconWindow(pid); stats[@"uniqueSystemDesktopLayer"]=@(iconPlane!=0);
    stats[@"containerBindsNativeLayer"]=@(belongsToDesktop(root,pid,iconPlane));
    AXUIElementRef finderApp=AXUIElementCreateApplication(pid); AXUIElementSetMessagingTimeout(finderApp,.12);
    CGRect areas[]={{ {1384,780},{86,176} },{{0,780},{86,176}},{{1384,0},{86,956}},{{0,0},{86,956}}};
    for(unsigned depth=0;depth<4 && level.count;depth++) {
        NSMutableArray *next=[NSMutableArray array];
        for(id obj in level) {
            AXUIElementRef node=(__bridge AXUIElementRef)obj;
            CFIndex count=-1; AXError status=AXUIElementGetAttributeValueCount(node,kAXChildrenAttribute,&count);
            if(status!=kAXErrorSuccess || count<0 || count>256 || seen.count+(unsigned long)count>512) { stats[@"completeGeometry"]=@NO; continue; }
            if(!count) continue;
            CFArrayRef raw=NULL; status=AXUIElementCopyAttributeValues(node,kAXChildrenAttribute,0,count,&raw);
            if(status!=kAXErrorSuccess || !raw || CFArrayGetCount(raw)!=count) { if(raw) CFRelease(raw); stats[@"completeGeometry"]=@NO; continue; }
            NSArray *children=CFBridgingRelease(raw);
            for(id child in children) {
                AXUIElementRef item=(__bridge AXUIElementRef)child;
                pid_t owner=0;
                if(CFGetTypeID(item)!=AXUIElementGetTypeID() || AXUIElementGetPid(item,&owner)!=kAXErrorSuccess || owner!=pid || [seen containsObject:child]) { stats[@"completeGeometry"]=@NO; continue; }
                [seen addObject:child];
                NSString *role=genericRole(item); roleCounts[role]=@([roleCounts[role] unsignedIntValue]+1);
                if([@[@"AXList",@"AXGroup",@"AXLayoutArea"] containsObject:role]) {
                    if(depth+1<4) [next addObject:child]; else stats[@"completeGeometry"]=@NO;
                    continue;
                }
                if(![@[@"AXImage",@"AXButton",@"AXCell"] containsObject:role]) { stats[@"completeGeometry"]=@NO; continue; }
                CFTypeRef p=NULL,s=NULL; CGPoint xy=CGPointZero; CGSize wh=CGSizeZero;
                BOOL ok=AXUIElementCopyAttributeValue(item,kAXPositionAttribute,&p)==kAXErrorSuccess && p && CFGetTypeID(p)==AXValueGetTypeID() && AXValueGetValue(p,kAXValueCGPointType,&xy) &&
                    AXUIElementCopyAttributeValue(item,kAXSizeAttribute,&s)==kAXErrorSuccess && s && CFGetTypeID(s)==AXValueGetTypeID() && AXValueGetValue(s,kAXValueCGSizeType,&wh) && isfinite(xy.x) && isfinite(xy.y) && wh.width>0 && wh.height>0;
                if(p) CFRelease(p); if(s) CFRelease(s);
                if(!ok) { stats[@"completeGeometry"]=@NO; continue; }
                measuredItems++;
                if(belongsToDesktop(item,pid,iconPlane)) nativeBound++;
                AXUIElementRef hit=NULL;
                if(AXUIElementCopyElementAtPosition(finderApp,xy.x+wh.width/2,xy.y+wh.height/2,&hit)==kAXErrorSuccess && hit) {
                    if(CFEqual(hit,item)) hitMatches++; CFRelease(hit);
                }
                for(unsigned i=0;i<4;i++) if(CGRectIntersectsRect((CGRect){xy,wh},areas[i])) overlap[i]++;
            }
        }
        level=next;
    }
    CFRelease(finderApp);
    stats[@"measuredItems"]=@(measuredItems); stats[@"itemsBoundToDesktopLayer"]=@(nativeBound); stats[@"positiveItemCenterHits"]=@(hitMatches);
    stats[@"roles"]=roleCounts; stats[@"intersections"]=@[@(overlap[0]),@(overlap[1]),@(overlap[2]),@(overlap[3])];
    return stats;
}
static NSDictionary *roots(AXUIElementRef app, pid_t pid, CGRect display) {
    CFIndex count=0;
    AXError e=AXUIElementGetAttributeValueCount(app,kAXChildrenAttribute,&count);
    NSMutableDictionary *r=[@{@"childrenStatus":@(e)} mutableCopy];
    if(e!=kAXErrorSuccess || count<1 || count>128) return r;
    CFArrayRef raw=NULL;
    e=AXUIElementCopyAttributeValues(app,kAXChildrenAttribute,0,count,&raw);
    r[@"childrenReadStatus"]=@(e);
    if(e!=kAXErrorSuccess || !raw) return r;
    NSArray *children=CFBridgingRelease(raw);
    NSMutableArray *containers=[NSMutableArray array];
    for(id object in children) {
        AXUIElementRef item=(__bridge AXUIElementRef)object;
        pid_t actual=0;
        if(CFGetTypeID(item)!=AXUIElementGetTypeID() || AXUIElementGetPid(item,&actual)!=kAXErrorSuccess || actual!=pid) continue;
        NSString *role=genericRole(item);
        if(![@[@"AXScrollArea",@"AXList",@"AXGroup",@"AXLayoutArea"] containsObject:role]) continue;
        // Only app-level containers with an exact physical-display frame qualify for comparison.
        if(coversDisplay(item,display)) [containers addObject:object];
    }
    NSMutableArray *candidates=[NSMutableArray array];
    for(id object in containers) [candidates addObject:genericRole((__bridge AXUIElementRef)object)];
    r[@"fullDisplayAppLevelContainerRoles"]=candidates;
    if(containers.count==1 && [candidates[0] isEqual:@"AXScrollArea"]) r[@"aggregateChildGeometry"]=inventory((__bridge AXUIElementRef)containers[0],pid);
    CGPoint p[]={{1385,781},{1468,781},{1427,868},{1385,954},{1468,954}};
    unsigned finder=0,matched=0;
    for(unsigned i=0;i<5;i++) {
        AXUIElementRef hit=NULL;
        if(AXUIElementCopyElementAtPosition(app,p[i].x,p[i].y,&hit)!=kAXErrorSuccess || !hit) continue;
        BOOL isMatch=NO;
        for(unsigned depth=0;depth<8;depth++) {
            pid_t actual=0;
            if(AXUIElementGetPid(hit,&actual)!=kAXErrorSuccess || actual!=pid) break;
            if(!depth) finder++;
            if([containers containsObject:(__bridge id)hit]) { isMatch=YES; break; }
            // Ordinary Finder windows are outside the scope of this observation.
            if([genericRole(hit) isEqual:@"AXWindow"]) break;
            CFTypeRef parent=NULL;
            if(AXUIElementCopyAttributeValue(hit,kAXParentAttribute,&parent)!=kAXErrorSuccess || !parent) break;
            if(CFGetTypeID(parent)!=AXUIElementGetTypeID() || CFEqual(parent,hit)) { CFRelease(parent); break; }
            CFRelease(hit); hit=(AXUIElementRef)parent;
        }
        if(isMatch) matched++;
        CFRelease(hit);
    }
    r[@"pointCount"]=@5; r[@"finderOwnedHits"]=@(finder); r[@"hitsBoundToFullDisplayContainer"]=@(matched);
    return r;
}
int main(void) { @autoreleasepool {
    NSArray *apps=[NSRunningApplication runningApplicationsWithBundleIdentifier:@"com.apple.finder"];
    NSRunningApplication *f=apps.count==1 ? apps.firstObject : nil;
    CGRect display=CGDisplayBounds(CGMainDisplayID());
    NSMutableDictionary *r=[@{@"status":@"BLOCKED",@"scope":@"public Finder app-level container geometry and hit ancestry",
        @"windowWrites":@0,@"inputs":@0,@"pixels":@0,@"documentContents":@0,@"namesRead":@0} mutableCopy];
    if(f && !f.terminated && appleFinder(f.processIdentifier) && AXIsProcessTrusted() &&
        CGRectEqualToRect(display,CGRectMake(0,0,1470,956))) {
        AXUIElementRef app=AXUIElementCreateApplication(f.processIdentifier);
        AXUIElementSetMessagingTimeout(app,0.12);
        NSDictionary *first=roots(app,f.processIdentifier,display);
        usleep(125000);
        NSDictionary *second=roots(app,f.processIdentifier,display);
        r[@"samples"]=@[first,second]; r[@"sameProcess"]=@(!f.terminated);
        r[@"status"]=(!f.terminated && [first isEqual:second] && second[@"pointCount"]) ? @"OBSERVED" : @"UNKNOWN";
        CFRelease(app);
    }
    NSData *data=[NSJSONSerialization dataWithJSONObject:r options:NSJSONWritingPrettyPrinted|NSJSONWritingSortedKeys error:NULL];
    if(!data || fwrite(data.bytes,1,data.length,stdout)!=data.length) return 3;
    puts("");return [r[@"status"] isEqual:@"OBSERVED"] ? 0 : 2;
}}
