#import "macos.m"
// Same native decision used by both the Host and Guardian before their AX setter.
// This executable never calls a window setter or a preference synchronization API.
bool readNativeYield(void) { return stageManagerYieldsWindowDispatch(); }
